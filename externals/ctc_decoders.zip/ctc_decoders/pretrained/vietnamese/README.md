## Vietnamese KenLM models

Pretrained models are here: arpa file, binary file

### Dataset

Get from [https://github.com/duyvuleo/VNTC](https://github.com/duyvuleo/VNTC) which contains 54981912 vietnamese words.

### KenLM

Binary file model is a 5-gram language model using probing.

Link: [https://drive.google.com/drive/folders/1GHQZ2Z5X0nTQ605mZrCVy8DcC1acScqG?usp=sharing](https://drive.google.com/drive/folders/1GHQZ2Z5X0nTQ605mZrCVy8DcC1acScqG?usp=sharing)
