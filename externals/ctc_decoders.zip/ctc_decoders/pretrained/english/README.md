## English pretrained KenLM models

Pretrained models can be found in
[http://openslr.org/11/](http://openslr.org/11/)
